#include "main.h"         /* <= own header */

#include "sAPI.h"         /* <= sAPI header */

#define BAUD_RATE 9600

void prenderVerde(void){
	digitalWrite( LEDG, ON );
	digitalWrite( LED1, OFF );
	digitalWrite( LED2, OFF );
}



/* Prendo solo el led amrillo del semáforo, apago los demás */
void prenderAmarillo(void){
	digitalWrite( LEDG, OFF );
	digitalWrite( LED1, ON );
	digitalWrite( LED2, OFF );
}

/* Prendo solo el led rojo del semáforo, apago los demás */
void prenderRojo(void){
	digitalWrite( LEDG, OFF );
	digitalWrite( LED1, OFF );
	digitalWrite( LED2, ON );
}

void prenderRojoAmarillo(void){
	digitalWrite( LEDG, OFF );
	digitalWrite( LED1, ON );
	digitalWrite( LED2, ON );
}

typedef enum{ROJO,ROJO_AMARILLO,VERDE,AMARILLO} estadosMEF;
estadosMEF estadoActual;
void InicializarMEF (void);
void ActualizarMEF(void);

/* Variable de Retardo no bloqueante */
delay_t delayBase;

uint8_t i = 0;

uint8_t time_uart,option,data,timeR,timeRA,timeV,timeA;

 /* FUNCION PRINCIPAL, PUNTO DE ENTRADA AL PROGRAMA LUEGO DE RESET. */
int main(void)
{
   /* ------------- INICIALIZACIONES ------------- */

   /* Inicializar la placa */
   boardConfig();

   /* Inicializar el conteo de Ticks con resolución de 1ms */
   tickConfig(1,0);

   /* Inicializar DigitalIO */
   digitalConfig( 0, ENABLE_DIGITAL_IO );

   /* Configuración de pines de entrada para
	   Teclas de la CIAA-NXP */
   digitalConfig( TEC1, INPUT );
   digitalConfig( TEC2, INPUT );
   digitalConfig( TEC3, INPUT );
   digitalConfig( TEC4, INPUT );

   /* Configuración de pines de salida para
	   Leds de la CIAA-NXP */
   digitalConfig( LEDR, OUTPUT );
   digitalConfig( LEDG, OUTPUT );
   digitalConfig( LEDB, OUTPUT );
   digitalConfig( LED1, OUTPUT );
   digitalConfig( LED2, OUTPUT );
   digitalConfig( LED3, OUTPUT );

   /* Inicializar Retardo no bloqueante con tiempo en ms
	   500 ms = 0,5 s */
   delayConfig( &delayBase, 1000 );
   
    /* Inicializar Uart */
    uartConfig(UART_USB, BAUD_RATE);
	
	InicializarMEF();
	bool_t valor,show_menu;
	

   /* ------------- REPETIR POR SIEMPRE ------------- */
	while(1) 
	{
		
		ActualizarMEF();
		valor = !digitalRead( TEC1 );
		digitalWrite( LEDB, valor );
		if (valor)
		{
			show_menu=TRUE;
		}
		if (show_menu)
		{
			show_menu=0;
			uartWriteString(UART_USB, (uint8_t*) "Men� de Configuraci�n\r\n");
			uartWriteString(UART_USB, (uint8_t*) "---------------------\r\n");
			uartWriteString(UART_USB, (uint8_t*) "1 - Tiempo de verde\r\n");
			uartWriteString(UART_USB, (uint8_t*) "2 - Tiempo de rojo\r\n");
			uartWriteString(UART_USB, (uint8_t*) "3 - Tiempo de amarillo\r\n");
			uartWriteString(UART_USB, (uint8_t*) "4 - Tiempo de rojo-amarillo\r\n");
			uartWriteString(UART_USB, (uint8_t*) "Presione enter y luego escriba el n�mero\r\n");
			
			option = uartReadByte(UART_USB);
			
			while (option!=13)
			{
				if (option)
					data=option;
				option = uartReadByte(UART_USB);
				uartWriteByte(UART_USB, option);
			}
			uartWriteString(UART_USB, (uint8_t*) "\r\n");

			switch(data)
			{
			case '1':
			{
				uartWriteString(UART_USB, (uint8_t*) "Escriba el nuevo tiempo para verde\r\n");
				option = uartReadByte(UART_USB);
				while (option!=13)
				{
					if (option)
						timeV=option-48;
					option = uartReadByte(UART_USB);
					uartWriteByte(UART_USB, option);

				}
			}
			break;
			case '2':
			{
				uartWriteString(UART_USB, (uint8_t*) "Escriba el nuevo tiempo para rojo\r\n");
				option = uartReadByte(UART_USB);
				while (option!=13)
				{
					if (option)
						timeR=option-48;
					option = uartReadByte(UART_USB);
					uartWriteByte(UART_USB, option);

				}
			}
			break;
			case '3':
			{
				uartWriteString(UART_USB, (uint8_t*) "Escriba el nuevo tiempo para amarillo\r\n");
				option = uartReadByte(UART_USB);
				while (option!=13)
				{
					if (option)
						timeA=option-48;
					option = uartReadByte(UART_USB);
					uartWriteByte(UART_USB, option);

				}
			}
			break;
			case '4':
			{
				uartWriteString(UART_USB, (uint8_t*) "Escriba el nuevo tiempo para rojo-amarillo\r\n");
				option = uartReadByte(UART_USB);
				while (option!=13)
				{
					if (option)
						timeRA=option-48;
					option = uartReadByte(UART_USB);
					uartWriteByte(UART_USB, option);

				}
			}
			break;

			}
		}

    }

	
	return 0 ;
}

void InicializarMEF()
{
	estadoActual=ROJO;
}

void ActualizarMEF()
{
	switch(estadoActual)
	{
		case ROJO:
		{
			prenderRojo();
			if (delayRead(&delayBase))
			{
				i++;
				if (i>=timeR)
				{
					estadoActual = ROJO_AMARILLO;
					i=0;
				}
			}
			
			
		}
		break;
		
		case ROJO_AMARILLO:
		{
			prenderRojoAmarillo();
			if (delayRead(&delayBase))
			{
				i++;
				if (i>=timeRA)
				{
					estadoActual = VERDE;
					i=0;
				}
			}
			
		}
		break;
		
		case VERDE:
		{
			prenderVerde();
			if (delayRead(&delayBase))
			{
				i++;
				if (i>=timeV)
				{
					estadoActual = AMARILLO;
					i=0;
				}
			}
			
		}
		break;
		
		case AMARILLO:
		{
			prenderAmarillo();
			if (delayRead(&delayBase))
			{
				i++;
				if (i>=timeA)
				{
					estadoActual = ROJO;
					i=0;
				}
			}
			
		}
		break;
		default:
		{
			InicializarMEF();
		}
		break;
	}
}

