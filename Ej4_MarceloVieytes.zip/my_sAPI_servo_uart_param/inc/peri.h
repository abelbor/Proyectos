/*
 * peri.h
 *
 *  Created on: 9/9/2016
 *      Author: Marcelo
 */

#ifndef _PERI_H_
#define _PERI_H_

#include "teclas.h"
#include "leds.h"

#endif /* _PERI_H_ */
