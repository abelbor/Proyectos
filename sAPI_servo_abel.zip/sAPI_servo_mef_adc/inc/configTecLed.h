#ifndef _CONFIGTECLED_H_
#define _CONFIGTECLED_H_

void configTecLed(void);

#endif
