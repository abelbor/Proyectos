#ifndef _DEBOUNCEMEF_H_
#define _DEBOUNCEMEF_H_

void IniciaMEF(void);
void ActualizaMEF(void);
void ControlServoUart(void);
void ControlServoAdc(void);

#endif
